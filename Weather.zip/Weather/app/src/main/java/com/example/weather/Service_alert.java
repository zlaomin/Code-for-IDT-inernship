package com.example.weather;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Binder;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;

public class Service_alert extends Service {
//    @androidx.annotation.Nullable
    private  Check_tp check_tp = null;
    private NotificationManager notificationMgr;
    private  Service_alert service_alert = this;
    private  long refreshtime = 5000;//5mins each time 300000, 5s 5000 for test.
    private  weather myweather = null;

    @Override
    public void onCreate() {
        Thread thr = new Thread(null, new ServiceWorker(), "BackgroundSercie");
        thr.start();
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.v("tag","as");

        return super.onStartCommand(intent, flags, startId);
    }


    @Override
    public void onDestroy() {
        Log.v("tag","as");
        super.onDestroy();
    }

//    @androidx.annotation.Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    // for update time


    // thread for check temp
    public class Check_tp extends Thread {
        @Override
        public void run() {
            super.run();
//            Getweather getweather = new Getweather(city);
//            myweather=getweather.get_weather();
//            Log.v("???",""+myweather.tem);

        }
    }

    //thread for check position

    //service worker
    class ServiceWorker implements Runnable{

        @Override
        public void run() {
            while(true){
                //thread is efficent than timer
                //so use thread
                try {
                    Thread.sleep(refreshtime);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                if(check_tp == null) {
                    check_tp = new Check_tp();
                    check_tp.start();
                }
                else
                {
                    if(!check_tp.isAlive()) {
                        check_tp = new Check_tp();
                        check_tp.start();
                    }
                }
            }

        }
    }
}
