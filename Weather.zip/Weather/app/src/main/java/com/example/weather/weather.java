package com.example.weather;

public class weather {
    public double tem;
    public double max_tem;
    public double min_tem;
    public String weather;
    public int weather_id;
    public String icon;
    public String data;
    public  weather(){

    }
    public void setweather(double tem, String weather, int weather_id, String icon, double max, double min,String data){
        this.icon =icon;
        this.tem = tem;
        this.weather_id =weather_id;
        this.weather = weather;
        this.max_tem=max;
        this.min_tem=min;
        this.data =data;
    }

}
