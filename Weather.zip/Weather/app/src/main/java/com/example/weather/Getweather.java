package com.example.weather;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class Getweather {
    //In Android 9, Cleartext HTTP is disabled as default. I changed it as enable.
    private String unit = "imperial";
    private String baseUrl = "http://api.openweathermap.org/data/2.5/weather?";
    private String preUrl = "http://api.openweathermap.org/data/2.5/forecast?";
    Getweather(){
    }
    public  weather get_weather(String local){
        if (local ==null)
            local="q=Hoboken,US";
        else
            local="q="+local;
        HttpURLConnection htt = null;
        HttpURLConnection httpro = null;
        InputStream ipt = null;
        InputStream iptpro = null;
        weather w= new weather();
        try{
            StringBuffer strbu= new StringBuffer();
            String url= baseUrl+local+"&units="+unit+"&appid="+"d58b7121af739946af97beb52726d8ba";
            String urlbro = preUrl+local+"&units="+unit+"&appid="+"d58b7121af739946af97beb52726d8ba";
            htt = (HttpURLConnection) ( new URL(url)).openConnection();
            htt.setRequestMethod("GET");
            htt.setDoInput(true);
            htt.setDoOutput(true);
            htt.connect();
            ipt = htt.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(ipt));
            String line =null;
            while((line =br.readLine()) != null)
                strbu.append(line+"\n");
            br.close();

            //get from Json and store in weather
            JSONObject jobj = new JSONObject(strbu.toString());
            String s_weather =  jobj.getString("weather");
            String s_main =  jobj.getString("main");
            s_weather=s_weather.substring(1,s_weather.length());
            JSONObject w_jobj = new JSONObject(s_weather);
            JSONObject m_jobj = new JSONObject(s_main);
            w.setweather(m_jobj.getDouble("temp"),w_jobj.getString("main"),w_jobj.getInt("id")
                    ,w_jobj.getString("icon"),m_jobj.getDouble("temp_max"),m_jobj.getDouble("temp_min"),null);
        }
            catch (Throwable t){
                t.printStackTrace();
            }
            finally {
            try { ipt.close(); } catch(Throwable t) {}
            try { htt.disconnect(); } catch(Throwable t) {}
        }
        return w;
    }
    public  List<weather>  get_forecast(String local){
        if (local ==null)
            local="q=Hoboken,US";
        else
            local="q="+local;
        HttpURLConnection htt = null;
        HttpURLConnection httpro = null;
        InputStream ipt = null;
        InputStream iptpro = null;
        List<weather> list_weather = new ArrayList<weather>();
        try{
            StringBuffer strbu= new StringBuffer();
            String url = preUrl+local+"&units="+unit+"&appid="+"d58b7121af739946af97beb52726d8ba";
            htt = (HttpURLConnection) ( new URL(url)).openConnection();
            htt.setRequestMethod("GET");
            htt.setDoInput(true);
            htt.setDoOutput(true);
            htt.connect();
            ipt = htt.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(ipt));
            String line =null;
            while((line =br.readLine()) != null)
                strbu.append(line+"\n");
            br.close();
            //get from Json and store in weather
            JSONObject jsonObject = new JSONObject(strbu.toString());
            String sl = jsonObject.getString("list");
            JSONArray jsonArray = new JSONArray(sl);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject t_jsonObject = jsonArray.getJSONObject(i);
                String s_weather =  t_jsonObject.getString("weather");
                String s_main =  t_jsonObject.getString("main");
                s_weather=s_weather.substring(1,s_weather.length());
                String data = t_jsonObject.getString("dt_txt");
                JSONObject w_jobj = new JSONObject(s_weather);
                JSONObject m_jobj = new JSONObject(s_main);
                weather w= new weather();
                w.setweather(m_jobj.getDouble("temp"),w_jobj.getString("main"),w_jobj.getInt("id")
                        ,w_jobj.getString("icon"),m_jobj.getDouble("temp_max"),m_jobj.getDouble("temp_min"),data);
                list_weather.add(w);
            }

        }
        catch (Throwable t){
            t.printStackTrace();
        }
        finally {
            try { ipt.close(); } catch(Throwable t) {}
            try { htt.disconnect(); } catch(Throwable t) {}
        }
        return list_weather;
    }
}

