package lecho.lib.hellocharts.animation;

public class DummyChartAnimationListener implements ChartAnimationListener {

    @Override
    public void onAnimationStarted() {
        // do nothing

    }

    @Override
    public void onAnimationFinished() {
        // do nothing

    }

}
